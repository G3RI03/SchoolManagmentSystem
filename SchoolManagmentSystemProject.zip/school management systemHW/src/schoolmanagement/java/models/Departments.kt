package schoolmanagement.java.models

class Departments {
    var id: String? = null
    var department: String? = null
    override fun toString(): String {
        return "$department"
    }


}