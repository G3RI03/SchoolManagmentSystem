package schoolmanagement.java.utils;

import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class RecursiveUser extends RecursiveTreeObject<RecursiveUser> {
    StringProperty userName, email;

    public RecursiveUser(String userName, String email) {
        this.userName = new SimpleStringProperty(userName);
        this.email = new SimpleStringProperty(email);
    }

    public String getUserName() {
        return userName.get();
    }

    public void setUserName(String userName) {
        this.userName.set(userName);
    }

    public StringProperty userNameProperty() {
        return userName;
    }

    public String getEmail() {
        return email.get();
    }

    public void setEmail(String email) {
        this.email.set(email);
    }

    public StringProperty emailProperty() {
        return email;
    }
}
