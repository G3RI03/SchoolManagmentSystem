package schoolmanagement

import schoolmanagement.java.main.Launcher

object Main {
    @JvmStatic
    fun main(args: Array<String>) {
        Launcher.main(args)
    }
}